#pragma once

#define ECHO_SERVICE_NAME   "echo_memchannel_service"




